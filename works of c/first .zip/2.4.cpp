#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
	printf("a= 5,b= 7,a-b=-2,a/b= 71%%\nc1 = COMPUTER, c2 = COMP, c3 = COMP\nx = 31.19, y = -31.2, z = 31.1900\ns = 3.11900e+002, t = -3.12e+001");

	return 0;
}

